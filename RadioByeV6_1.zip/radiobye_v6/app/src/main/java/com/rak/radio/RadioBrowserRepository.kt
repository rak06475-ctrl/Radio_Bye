package com.rak.radio

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

data class Country(val code: String, val name: String, val stationCount: Int)

data class Station(
    val uuid: String,
    val name: String,
    val streamUrl: String,
    val favicon: String?,
    val countryCode: String,
    val country: String,
    val language: String,
    val tags: String,
    val codec: String,
    val bitrate: Int,
    val homepage: String?
)

object RadioBrowserRepository {
    private const val BASE = "https://de1.api.radio-browser.info"
    private const val USER_AGENT = "RadioBye/6.1 Android"

    suspend fun popular(limit: Int = 60): List<Station> =
        request("/json/stations/topclick?limit=$limit&hidebroken=true")

    suspend fun byCountry(code: String, limit: Int = 60): List<Station> =
        request("/json/stations/search?countrycode=${enc(code)}&order=clickcount&reverse=true&limit=$limit&hidebroken=true")

    suspend fun search(query: String, limit: Int = 60): List<Station> =
        request("/json/stations/search?name=${enc(query)}&order=clickcount&reverse=true&limit=$limit&hidebroken=true")

    suspend fun byTag(tag: String, limit: Int = 60): List<Station> =
        request("/json/stations/search?tag=${enc(tag)}&order=clickcount&reverse=true&limit=$limit&hidebroken=true")

    suspend fun countries(limit: Int = 80): List<Country> = withContext(Dispatchers.IO) {
        val connection = (URL(BASE + "/json/countries?order=stationcount&reverse=true&limit=$limit").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            setRequestProperty("User-Agent", USER_AGENT)
            setRequestProperty("Accept", "application/json")
            connectTimeout = 8000
            readTimeout = 10000
        }
        try {
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val array = JSONArray(body)
            buildList {
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    val code = o.optString("iso_3166_1")
                    val name = o.optString("name")
                    if (code.isNotBlank() && name.isNotBlank()) add(Country(code, name, o.optInt("stationcount")))
                }
            }
        } finally { connection.disconnect() }
    }

    fun countClick(uuid: String) {
        Thread {
            runCatching {
                val connection = URL("$BASE/json/url/$uuid").openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.setRequestProperty("User-Agent", USER_AGENT)
                connection.connectTimeout = 5000
                connection.readTimeout = 5000
                connection.inputStream.use { it.readBytes() }
                connection.disconnect()
            }
        }.start()
    }

    private suspend fun request(path: String): List<Station> = withContext(Dispatchers.IO) {
        val connection = (URL(BASE + path).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            setRequestProperty("User-Agent", USER_AGENT)
            setRequestProperty("Accept", "application/json")
            connectTimeout = 8000
            readTimeout = 10000
        }
        try {
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            parse(body)
        } finally {
            connection.disconnect()
        }
    }

    private fun parse(body: String): List<Station> {
        val array = JSONArray(body)
        return buildList {
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                val url = o.optString("url_resolved").ifBlank { o.optString("url") }
                val uuid = o.optString("stationuuid")
                if (uuid.isNotBlank() && url.isNotBlank()) {
                    add(
                        Station(
                            uuid = uuid,
                            name = o.optString("name").ifBlank { "Radio" },
                            streamUrl = url,
                            favicon = o.optString("favicon").ifBlank { null },
                            countryCode = o.optString("countrycode"),
                            country = o.optString("country"),
                            language = o.optString("language"),
                            tags = o.optString("tags"),
                            codec = o.optString("codec"),
                            bitrate = o.optInt("bitrate"),
                            homepage = o.optString("homepage").ifBlank { null }
                        )
                    )
                }
            }
        }
    }

    private fun enc(value: String): String =
        URLEncoder.encode(value, Charsets.UTF_8.name())
}
