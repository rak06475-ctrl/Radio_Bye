package com.rak.radio

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil3.compose.AsyncImage
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private val Green = Color(0xFF39D98A)
private val Cyan = Color(0xFF72E5FF)
private val Dark = Color(0xFF080C10)
private val Card = Color(0xFF151B22)

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        val token = SessionToken(this, ComponentName(this, RadioPlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        setContent { RadioByeV6(controllerFuture, getPreferences(Context.MODE_PRIVATE)) }
    }
    override fun onDestroy() { controllerFuture?.let { MediaController.releaseFuture(it) }; super.onDestroy() }
}

@Composable
private fun RadioByeV6(future: ListenableFuture<MediaController>?, prefs: android.content.SharedPreferences) {
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { delay(1300); splash = false }
    DisposableEffect(future) {
        if (future != null) future.addListener({ controller = runCatching { future.get() }.getOrNull() }, { it.run() })
        onDispose { }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Green, secondary = Cyan, background = Dark, surface = Card)) {
        Box(Modifier.fillMaxSize().background(Dark)) {
            AnimatedVisibility(!splash, enter = fadeIn(), exit = fadeOut()) { RadioHomeV6(controller, prefs) }
            AnimatedVisibility(splash, enter = fadeIn(), exit = fadeOut()) { SplashScreen() }
        }
    }
}

@Composable private fun SplashScreen() {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0D1718), Dark))), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            LogoMark(96)
            Spacer(Modifier.height(20.dp))
            Text("Radio Bye", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(6.dp))
            Text("صوتك أينما كنت", color = Color.Gray)
            Spacer(Modifier.height(28.dp))
            CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun RadioHomeV6(controller: MediaController?, prefs: android.content.SharedPreferences) {
    val scope = rememberCoroutineScope(); val context = LocalContext.current
    var stations by remember { mutableStateOf<List<Station>>(emptyList()) }
    var selected by remember { mutableStateOf<Station?>(null) }
    var detail by remember { mutableStateOf<Station?>(null) }
    var nowPlaying by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("الأكثر استماعاً") }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableIntStateOf(0) }
    var showSleep by remember { mutableStateOf(false) }; var showCountries by remember { mutableStateOf(false) }
    var sleepMinutes by remember { mutableIntStateOf(0) }
    var history by remember { mutableStateOf(loadHistory(prefs)) }
    var favorites by remember { mutableStateOf(prefs.getStringSet("favorite_ids", emptySet())?.toSet() ?: emptySet()) }

    fun load(block: suspend () -> List<Station>) = scope.launch {
        loading = true; error = null
        runCatching { block() }.onSuccess { r -> stations = r; if (selected == null && r.isNotEmpty()) selected = r.first() }
            .onFailure { error = "تعذر تحميل المحطات. تحقق من اتصال الإنترنت." }
        loading = false
    }
    fun play(s: Station) {
        selected = s
        controller?.setMediaItem(MediaItem.Builder().setUri(s.streamUrl).setMediaId(s.uuid).setTag(s.name).build())
        controller?.prepare(); controller?.play(); RadioBrowserRepository.countClick(s.uuid)
        history = listOf(s) + history.filterNot { it.uuid == s.uuid }.take(9); saveHistory(prefs, history)
    }
    fun favorite(s: Station) { val n=favorites.toMutableSet(); if(!n.add(s.uuid)) n.remove(s.uuid); favorites=n; prefs.edit().putStringSet("favorite_ids",n).apply() }
    fun sleep(m:Int) { sleepMinutes=m; showSleep=false; scope.launch { delay(m*60_000L); controller?.pause(); sleepMinutes=0 } }
    LaunchedEffect(Unit) { load { RadioBrowserRepository.popular() } }
    DisposableEffect(controller) {
        if(controller==null) return@DisposableEffect onDispose { }
        val l=object: androidx.media3.common.Player.Listener { override fun onIsPlayingChanged(v:Boolean){nowPlaying=v} }
        controller.addListener(l); nowPlaying=controller.isPlaying; onDispose { controller.removeListener(l) }
    }

    if(detail!=null) { NowPlayingScreen(detail!!, nowPlaying, favorites.contains(detail!!.uuid), onBack={detail=null}, onPlay={play(detail!!)}, onFavorite={favorite(detail!!)}, onShare={share(context,detail!!)}); return }
    val visible=when(tab){1->history;2->stations.filter{favorites.contains(it.uuid)};else->stations}
    Scaffold(containerColor=Dark, topBar={
        TopAppBar(title={Row(verticalAlignment=Alignment.CenterVertically){LogoMark(38);Spacer(Modifier.width(10.dp));Column{Text("Radio Bye",fontWeight=FontWeight.Bold);Text("استمع بلا حدود",style=MaterialTheme.typography.labelSmall,color=Color.Gray)}}},actions={
            IconButton({showCountries=true}){Icon(Icons.Default.Public,"البلدان")}; IconButton({showSleep=true}){Icon(Icons.Default.Bedtime,"مؤقت النوم")}; IconButton({load{RadioBrowserRepository.popular()}}){Icon(Icons.Default.Refresh,"تحديث")}
        },colors=TopAppBarDefaults.topAppBarColors(containerColor=Dark))
    }, bottomBar={Column{selected?.let{s->MiniPlayer(s,nowPlaying,sleepMinutes,favorites.contains(s.uuid),{if(nowPlaying)controller?.pause()else play(s)},{favorite(s)},{detail=s},{share(context,s)})};NavigationBar(containerColor=Color(0xFF111820)){NavigationBarItem(tab==0,{tab=0},{Icon(Icons.Default.Radio,null)},label={Text("المحطات")});NavigationBarItem(tab==1,{tab=1},{Icon(Icons.Default.History,null)},label={Text("السجل")});NavigationBarItem(tab==2,{tab=2},{Icon(Icons.Default.Favorite,null)},label={Text("المفضلة")})}}}){p->
        Column(Modifier.fillMaxSize().padding(p).padding(horizontal=16.dp)){Spacer(Modifier.height(10.dp));
            OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),singleLine=true,placeholder={Text("ابحث عن محطة…")},leadingIcon={Icon(Icons.Default.Search,null)},trailingIcon={if(query.isNotBlank())IconButton({load{RadioBrowserRepository.search(query)}}){Icon(Icons.Default.Search,null)}})
            Spacer(Modifier.height(10.dp)); if(tab==0)Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){listOf("الأكثر استماعاً","ليبيا","موسيقى","أخبار","عربي").forEach{c->FilterChip(category==c,{category=c;when(c){"الأكثر استماعاً"->load{RadioBrowserRepository.popular()};"ليبيا"->load{RadioBrowserRepository.byCountry("LY")};"موسيقى"->load{RadioBrowserRepository.byTag("music")};"أخبار"->load{RadioBrowserRepository.byTag("news")};else->load{RadioBrowserRepository.byTag("arabic")}}},{Text(c)})}}
            Spacer(Modifier.height(12.dp));Text(when(tab){1->"آخر المحطات";2->"المفضلة";else->"اكتشف المحطات"},style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);Spacer(Modifier.height(6.dp))
            when{loading&&tab==0->Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){CircularProgressIndicator()};tab>0&&visible.isEmpty()->EmptyState(if(tab==1)"لا يوجد سجل استماع بعد." else "لم تضف أي محطة للمفضلة بعد.");error!=null&&tab==0->Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text(error!!,color=MaterialTheme.colorScheme.error)};else->LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(bottom=12.dp)){items(visible,key={it.uuid}){s->StationRow(s,favorites.contains(s.uuid),selected?.uuid==s.uuid,{play(s)},{favorite(s)},{detail=s})}}}
        }
    }
    if(showSleep)AlertDialog(onDismissRequest={showSleep=false},title={Text("مؤقت النوم")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){listOf(15,30,45,60,90).forEach{m->OutlinedButton({sleep(m)},Modifier.fillMaxWidth()){Text("$m دقيقة")}};if(sleepMinutes>0)Text("المؤقت الحالي: $sleepMinutes دقيقة")}},confirmButton={TextButton({sleepMinutes=0;showSleep=false}){Text("إلغاء")}})
    if(showCountries)CountryDialog({showCountries=false}){code->showCountries=false;tab=0;load{RadioBrowserRepository.byCountry(code)}}
}

@Composable private fun MiniPlayer(s:Station,playing:Boolean,sleep:Int,favorite:Boolean,onPlay:()->Unit,onFav:()->Unit,onDetails:()->Unit,onShare:()->Unit){Card(Modifier.fillMaxWidth().padding(8.dp),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFF18212B))){Row(Modifier.fillMaxWidth().clickable{onDetails()}.padding(10.dp),verticalAlignment=Alignment.CenterVertically){StationImage(s,52);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text("يُشغّل الآن",style=MaterialTheme.typography.labelSmall,color=Green);Text(s.name,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis);Text((if(playing)"● مباشر" else "متوقف")+(if(sleep>0)" • ⏱ $sleep د" else ""),color=Color.Gray,style=MaterialTheme.typography.labelSmall)};IconButton(onFav){Icon(if(favorite)Icons.Default.Favorite else Icons.Default.FavoriteBorder,"المفضلة")};FilledIconButton(onPlay){Icon(if(playing)Icons.Default.Pause else Icons.Default.PlayArrow,"تشغيل")}}}}

@Composable private fun NowPlayingScreen(s:Station,playing:Boolean,favorite:Boolean,onBack:()->Unit,onPlay:()->Unit,onFavorite:()->Unit,onShare:()->Unit){Scaffold(containerColor=Dark,topBar={TopAppBar(title={Text("يُشغّل الآن")},navigationIcon={IconButton(onBack){Icon(Icons.Default.ArrowBack,"رجوع")}},actions={IconButton(onShare){Icon(Icons.Default.Share,"مشاركة")}},colors=TopAppBarDefaults.topAppBarColors(containerColor=Dark))}){p->Column(Modifier.fillMaxSize().padding(p).padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally){Spacer(Modifier.height(30.dp));StationImage(s,210);Spacer(Modifier.height(22.dp));Text(s.name,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.ExtraBold,textAlign=TextAlign.Center);Text(if(playing)"🔴 بث مباشر الآن" else "جاهز للبث",color=if(playing)Green else Color.Gray);Spacer(Modifier.height(24.dp));Row(horizontalArrangement=Arrangement.spacedBy(12.dp),verticalAlignment=Alignment.CenterVertically){IconButton(onFavorite){Icon(if(favorite)Icons.Default.Favorite else Icons.Default.FavoriteBorder,"المفضلة",tint=if(favorite)Green else Color.White,modifier=Modifier.size(30.dp))};FilledIconButton(onPlay,Modifier.size(72.dp)){Icon(if(playing)Icons.Default.Pause else Icons.Default.PlayArrow,"تشغيل",modifier=Modifier.size(34.dp))};IconButton(onShare){Icon(Icons.Default.Share,"مشاركة",modifier=Modifier.size(30.dp))}};Spacer(Modifier.height(30.dp));InfoPill("الجودة",if(s.bitrate>0)"${s.bitrate} kbps" else "غير محددة");InfoPill("الترميز",s.codec.ifBlank{"غير معروف"});InfoPill("البلد",s.country.ifBlank{"غير محدد"})}}
}
@Composable private fun InfoPill(k:String,v:String){Card(Modifier.fillMaxWidth().padding(vertical=4.dp),colors=CardDefaults.cardColors(containerColor=Card)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Text(k,color=Color.Gray,modifier=Modifier.weight(1f));Text(v,fontWeight=FontWeight.SemiBold)}}}

@Composable private fun LogoMark(size:Int){Box(Modifier.size(size.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Green,Cyan))),contentAlignment=Alignment.Center){Icon(Icons.Default.Radio,null,tint=Dark,modifier=Modifier.size((size*.6).dp))}}
@Composable private fun EmptyState(t:String){Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.Radio,null,Modifier.size(52.dp),tint=Color.Gray);Spacer(Modifier.height(8.dp));Text(t,color=Color.Gray)}}}
@Composable private fun StationRow(s:Station,favorite:Boolean,selected:Boolean,onPlay:()->Unit,onFav:()->Unit,onDetails:()->Unit){Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=if(selected)Color(0xFF1D2B38) else Card)){Row(Modifier.fillMaxWidth().clickable{onDetails()}.padding(12.dp),verticalAlignment=Alignment.CenterVertically){StationImage(s,58);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(s.name,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis);Text(listOfNotNull(s.country.takeIf{it.isNotBlank()},s.language.takeIf{it.isNotBlank()},s.codec.takeIf{it.isNotBlank()},s.bitrate.takeIf{it>0}?.let{"$it kbps"}).joinToString(" • ").ifBlank{"بث مباشر"},color=Color.Gray,style=MaterialTheme.typography.bodySmall,maxLines=1,overflow=TextOverflow.Ellipsis)};IconButton(onFav){Icon(if(favorite)Icons.Default.Favorite else Icons.Default.FavoriteBorder,"المفضلة")};FilledTonalIconButton(onPlay){Icon(Icons.Default.PlayArrow,"تشغيل")}}}}
@Composable private fun StationImage(s:Station,size:Int){Box(Modifier.size(size.dp).clip(RoundedCornerShape(18.dp)).background(Color(0xFF202833)),contentAlignment=Alignment.Center){if(!s.favicon.isNullOrBlank())AsyncImage(model=s.favicon,contentDescription=s.name,modifier=Modifier.fillMaxSize(),contentScale=ContentScale.Crop)else Icon(Icons.Default.Radio,null,tint=Green,modifier=Modifier.size((size/2).dp))}}
@Composable private fun CountryDialog(onDismiss:()->Unit,onCountry:(String)->Unit){var cs by remember{mutableStateOf<List<Country>>(emptyList())};var l by remember{mutableStateOf(true)};LaunchedEffect(Unit){runCatching{RadioBrowserRepository.countries()}.onSuccess{cs=it};l=false};AlertDialog(onDismissRequest=onDismiss,title={Text("اختر البلد")},text={if(l)CircularProgressIndicator()else LazyColumn(Modifier.heightIn(max=430.dp)){items(cs,key={it.code}){c->Row(Modifier.fillMaxWidth().clickable{onCountry(c.code)}.padding(vertical=10.dp)){Text(c.name,Modifier.weight(1f));Text("${c.stationCount}",color=Color.Gray)}}}},confirmButton={TextButton(onDismiss){Text("إغلاق")}})}
private fun share(c:Context,s:Station){c.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,"${s.name}\n${s.streamUrl}")},"مشاركة المحطة"))}
private fun saveHistory(p:android.content.SharedPreferences,l:List<Station>){val a=JSONArray();l.take(10).forEach{s->a.put(JSONObject().apply{put("uuid",s.uuid);put("name",s.name);put("streamUrl",s.streamUrl);put("favicon",s.favicon ?: "")})};p.edit().putString("history_json",a.toString()).apply()}
private fun loadHistory(p:android.content.SharedPreferences):List<Station> = runCatching {
    val a=JSONArray(p.getString("history_json","[]") ?: "[]"); buildList {
        for(i in 0 until a.length()){val o=a.getJSONObject(i); add(Station(o.optString("uuid"),o.optString("name"),o.optString("streamUrl"),o.optString("favicon").ifBlank{null},o.optString("countryCode"),o.optString("country"),o.optString("language"),o.optString("tags"),o.optString("codec"),o.optInt("bitrate"),o.optString("homepage").ifBlank{null}))}
    }
}.getOrDefault(emptyList())
