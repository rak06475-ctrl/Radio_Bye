# Radio Bye

Android radio streaming app built with Kotlin + Jetpack Compose + Media3.

## Build
Open this folder in Android Studio with an Android SDK installed, then Sync Project with Gradle Files and run the `app` configuration.

## V6.1
- Fixed Kotlin source formatting issue in repository model declarations.
- App name: Radio Bye.
- Background playback via Media3 MediaSessionService.
- Radio Browser station discovery, search, countries, favorites, history, sleep timer, and now-playing screen.

## Note
A Gradle wrapper is not bundled in this archive, so Android Studio/Gradle installation is required to build the APK.
